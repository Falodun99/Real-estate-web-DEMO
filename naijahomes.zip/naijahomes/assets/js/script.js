'use strict';

/**
 * element toggle function
 */

const elemToggleFunc = function (elem) { elem.classList.toggle("active"); }



/**
 * navbar toggle
 */

const navbar = document.querySelector("[data-navbar]");
const overlay = document.querySelector("[data-overlay]");
const navCloseBtn = document.querySelector("[data-nav-close-btn]");
const navOpenBtn = document.querySelector("[data-nav-open-btn]");
const navbarLinks = document.querySelectorAll("[data-nav-link]");

const navElemArr = [overlay, navCloseBtn, navOpenBtn];

/**
 * close navbar when click on any navbar link
 */

for (let i = 0; i < navbarLinks.length; i++) { navElemArr.push(navbarLinks[i]); }

/**
 * addd event on all elements for toggling navbar
 */

for (let i = 0; i < navElemArr.length; i++) {
  navElemArr[i].addEventListener("click", function () {
    elemToggleFunc(navbar);
    elemToggleFunc(overlay);
  });
}



/**
 * header active state
 */

const header = document.querySelector("[data-header]");

window.addEventListener("scroll", function () {
  window.scrollY >= 400 ? header.classList.add("active")
    : header.classList.remove("active");
}); 

/* ==============================
   NAIJAHOMES BUTTON FUNCTIONALITY
   ============================== */

document.addEventListener("DOMContentLoaded", function () {

  /* PROFILE BUTTON */

  const profileButton = document.querySelector(
    '.header-bottom-actions-btn[aria-label="Profile"]'
  );

  const authModal = document.querySelector("#authModal");

  if (profileButton && authModal) {

    profileButton.addEventListener("click", function () {

      authModal.classList.add("active");

      document.body.classList.add("modal-open");

    });

  }


  /* CLOSE AUTH MODAL */

  const authCloseButtons = document.querySelectorAll(
    "[data-auth-close]"
  );

  authCloseButtons.forEach(function (button) {

    button.addEventListener("click", function () {

      authModal.classList.remove("active");

      document.body.classList.remove("modal-open");

    });

  });


  /* EXPLORE PROPERTIES */

  const exploreButton = document.querySelector(
    ".cta-btn"
  );

  if (exploreButton) {

    exploreButton.addEventListener("click", function () {

      const properties = document.querySelector("#property");

      if (properties) {

        properties.scrollIntoView({
          behavior: "smooth"
        });

      }

    });

  }


  /* HERO ENQUIRY */

  const enquiryButton = document.querySelector(
    ".hero .btn"
  );

  if (enquiryButton) {

    enquiryButton.addEventListener("click", function () {

      const contact = document.querySelector("#contact");

      if (contact) {

        contact.scrollIntoView({
          behavior: "smooth"
        });

      }

    });

  }


  /* FAVOURITE BUTTONS */

  const favouriteButtons = document.querySelectorAll(
    ".card-footer-actions-btn"
  );

  favouriteButtons.forEach(function (button) {

    const icon = button.querySelector("ion-icon");

    if (!icon) return;

    if (
      icon.getAttribute("name") === "heart-outline"
    ) {

      button.addEventListener("click", function () {

        const saved =
          button.classList.toggle("saved");

        if (saved) {

          icon.setAttribute(
            "name",
            "heart"
          );

        } else {

          icon.setAttribute(
            "name",
            "heart-outline"
          );

        }

      });

    }

  });

});




/* =========================
   PROPERTY SEARCH
========================= */

document.addEventListener("DOMContentLoaded", function () {

  const searchBtn = document.querySelector("#searchBtn");
  const searchModal = document.querySelector("#searchModal");
  const searchClose = document.querySelector("#searchClose");
  const searchForm = document.querySelector("#propertySearchForm");
  const searchInput = document.querySelector("#propertySearch");
  const searchResults = document.querySelector("#searchResults");


  /* OPEN SEARCH */

  if (searchBtn && searchModal) {

    searchBtn.addEventListener("click", function () {

      searchModal.classList.add("active");

      setTimeout(function () {
        searchInput.focus();
      }, 100);

    });

  }


  /* CLOSE SEARCH */

  if (searchClose) {

    searchClose.addEventListener("click", function () {

      searchModal.classList.remove("active");

    });

  }


  /* CLOSE WHEN CLICKING OUTSIDE */

  if (searchModal) {

    searchModal.addEventListener("click", function (event) {

      if (event.target === searchModal) {

        searchModal.classList.remove("active");

      }

    });

  }


  /* SEARCH PROPERTIES */

  if (searchForm) {

    searchForm.addEventListener("submit", function (event) {

      event.preventDefault();

      const query = searchInput.value.trim();

      if (query === "") {

        searchResults.innerHTML = `
          <div class="search-result-message">
            Please enter a location, property type or number of bedrooms.
          </div>
        `;

        return;

      }


      /* Find property cards */

      const propertyCards = document.querySelectorAll(
        ".property-card"
      );

      let found = 0;

      propertyCards.forEach(function (card) {

        const text = card.innerText.toLowerCase();

        if (text.includes(query.toLowerCase())) {

          card.style.display = "";

          found++;

        } else {

          card.style.display = "none";

        }

      });


      if (found > 0) {

        searchResults.innerHTML = `
          <div class="search-result-message">
            ${found} matching property${found > 1 ? "ies" : "y"} found.
          </div>
        `;

      } else {

        searchResults.innerHTML = `
          <div class="search-result-message">
            No properties found for "<strong>${query}</strong>".
          </div>
        `;

      }

    });

  }

});







/* =========================================================
   NAIJAHOMES AUTHENTICATION
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

  const authModal = document.getElementById("authModal");
  const authOverlay = document.getElementById("authOverlay");
  const authClose = document.getElementById("authClose");

  const loginPanel = document.getElementById("loginPanel");
  const registerPanel = document.getElementById("registerPanel");

  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");

  const showRegister = document.getElementById("showRegister");
  const showLogin = document.getElementById("showLogin");

  const authMessage = document.getElementById("authMessage");

  const profileButton = document.querySelector(
    '.header-bottom-actions-btn[aria-label="Profile"]'
  );


  /* =========================
     OPEN MODAL
  ========================= */

  function openAuth() {

    if (!authModal) return;

    authModal.classList.add("active");

    document.body.classList.add("auth-open");

    showLoginPanel();

  }


  /* =========================
     CLOSE MODAL
  ========================= */

  function closeAuth() {

    if (!authModal) return;

    authModal.classList.remove("active");

    document.body.classList.remove("auth-open");

    clearMessage();

  }


  /* =========================
     LOGIN PANEL
  ========================= */

  function showLoginPanel() {

    if (!loginPanel || !registerPanel) return;

    loginPanel.style.display = "block";
    registerPanel.style.display = "none";

    clearMessage();

  }


  /* =========================
     REGISTER PANEL
  ========================= */

  function showRegisterPanel() {

    if (!loginPanel || !registerPanel) return;

    loginPanel.style.display = "none";
    registerPanel.style.display = "block";

    clearMessage();

  }


  /* =========================
     MESSAGE
  ========================= */

  function showMessage(message, type) {

    if (!authMessage) return;

    authMessage.textContent = message;

    authMessage.className =
      "auth-message show " + type;

  }


  function clearMessage() {

    if (!authMessage) return;

    authMessage.textContent = "";

    authMessage.className =
      "auth-message";

  }


  /* =========================
     PROFILE BUTTON
  ========================= */

  if (profileButton) {

    profileButton.addEventListener("click", function (event) {

      event.preventDefault();

      openAuth();

    });

  }


  /* =========================
     CLOSE BUTTON
  ========================= */

  if (authClose) {

    authClose.addEventListener(
      "click",
      closeAuth
    );

  }


  /* =========================
     OVERLAY CLOSE
  ========================= */

  if (authOverlay) {

    authOverlay.addEventListener(
      "click",
      closeAuth
    );

  }


  /* =========================
     ESCAPE KEY
  ========================= */

  document.addEventListener(
    "keydown",
    function (event) {

      if (
        event.key === "Escape" &&
        authModal &&
        authModal.classList.contains("active")
      ) {

        closeAuth();

      }

    }
  );


  /* =========================
     SWITCH TO REGISTER
  ========================= */

  if (showRegister) {

    showRegister.addEventListener(
      "click",
      showRegisterPanel
    );

  }


  /* =========================
     SWITCH TO LOGIN
  ========================= */

  if (showLogin) {

    showLogin.addEventListener(
      "click",
      showLoginPanel
    );

  }


  /* =========================
     REGISTER
  ========================= */

  if (registerForm) {

    registerForm.addEventListener(
      "submit",
      function (event) {

        event.preventDefault();

        const name =
          document.getElementById(
            "registerName"
          ).value.trim();

        const email =
          document.getElementById(
            "registerEmail"
          ).value.trim().toLowerCase();

        const phone =
          document.getElementById(
            "registerPhone"
          ).value.trim();

        const password =
          document.getElementById(
            "registerPassword"
          ).value;

        const confirmPassword =
          document.getElementById(
            "confirmPassword"
          ).value;


        if (password !== confirmPassword) {

          showMessage(
            "Passwords do not match.",
            "error"
          );

          return;

        }


        if (password.length < 6) {

          showMessage(
            "Password must contain at least 6 characters.",
            "error"
          );

          return;

        }


        const user = {
          name: name,
          email: email,
          phone: phone,
          password: password
        };


        localStorage.setItem(
          "naijaHomesUser",
          JSON.stringify(user)
        );


        showMessage(
          "Account created successfully! You can now login.",
          "success"
        );


        registerForm.reset();


        setTimeout(function () {

          showLoginPanel();

          document.getElementById(
            "loginEmail"
          ).value = email;

        }, 1200);

      }
    );

  }


  /* =========================
     LOGIN
  ========================= */

  if (loginForm) {

    loginForm.addEventListener(
      "submit",
      function (event) {

        event.preventDefault();


        const email =
          document.getElementById(
            "loginEmail"
          ).value.trim().toLowerCase();

        const password =
          document.getElementById(
            "loginPassword"
          ).value;


        const savedUser =
          localStorage.getItem(
            "naijaHomesUser"
          );


        if (!savedUser) {

          showMessage(
            "No account found. Please create an account first.",
            "error"
          );

          return;

        }


        const user =
          JSON.parse(savedUser);


        if (
          email !== user.email ||
          password !== user.password
        ) {

          showMessage(
            "Incorrect email or password.",
            "error"
          );

          return;

        }


        localStorage.setItem(
          "naijaHomesLoggedIn",
          "true"
        );


        showMessage(
          "Login successful! Welcome back, " +
          user.name + ".",
          "success"
        );


        setTimeout(function () {

          closeAuth();

          loginForm.reset();

        }, 1000);

      }
    );

  }


  /* =========================
     FORGOT PASSWORD
  ========================= */

  const forgotPassword =
    document.getElementById(
      "forgotPassword"
    );


  if (forgotPassword) {

    forgotPassword.addEventListener(
      "click",
      function (event) {

        event.preventDefault();

        showMessage(
          "For this demo, please create a new account if you forgot your password.",
          "error"
        );

      }
    );

  }

});